package com.gimnastiar.skinnyappbeta.utils

data class UserData(
    val name: String?,
    val username: String?,
    val token: String?
)
