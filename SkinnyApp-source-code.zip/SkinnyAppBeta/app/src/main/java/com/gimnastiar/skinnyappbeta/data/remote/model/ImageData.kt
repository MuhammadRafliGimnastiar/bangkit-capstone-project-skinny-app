package com.gimnastiar.skinnyappbeta.data.remote.model

import android.widget.ImageView

data class ImageData(
    val image: Int
)
